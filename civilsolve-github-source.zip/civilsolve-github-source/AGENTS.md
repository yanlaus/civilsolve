# CivilSolve Agent Notes

This project is a Zo Site for civil engineering assignment solving. Follow these notes before changing code.

## First Reads

- Read `README.md` before editing.
- Then inspect the specific files you will touch.

## Core Invariants

- Keep API keys server-side only. Never expose `OPENAI_API_KEY`, `CODEX_API_KEY`, `POE_API_KEY`, or `ZO_CLIENT_IDENTITY_TOKEN` to frontend code.
- Keep `/api/solve` asynchronous. It must return a job id quickly and let the frontend poll `/api/jobs/:jobId`.
- Do not reintroduce a long blocking solve request. The published site can time out while providers keep running and charging credits.
- Provider failures should be per-provider errors when possible. A Claude failure should not hide Codex and Gemini results.
- Keep math rendering in the web UI. Users should be able to read formulas directly without downloading the PDF.
- Keep the TeX download hidden from the user-facing UI. The `.tex` route may remain for internal/debug compatibility and PDF artifacts.
- HEIC/HEIF/TIFF uploads are accepted, but should not be previewed with browser `<img>`.
- `.data/jobs` contains generated runtime data and user uploads. Do not commit it or use it as documentation.

## Zo Site Operations

- Zo manages the dev/prod process. Do not manually run or stop `bun run dev` or `bun run prod` for normal operation.
- Keep `bun run prod` as a fast server start only. Do not put `bun run build` back into the production entrypoint; building during service startup leaves the published port closed and can surface Cloudflare 521 while Zo/Cloudflare wait for the origin.
- `scripts/watchdog-daemon.py` recovers `supervisord-user` and the CivilSolve origin if they are terminated. Keep it executable. The durable service metadata should avoid supervisor secret placeholders such as `%(ENV_OPENAI_API_KEY)s` and `%(ENV_POE_API_KEY)s`; the published service entrypoint should source `/root/.zo_secrets` before `bun run prod` instead.
- Do not rely on `/etc/zo/supervisor.conf` for this watchdog as a durable registration point. Zo can regenerate that file on service-manager updates or host restarts, which removes custom programs.
- The watchdog should run outside `supervisord-user` itself. On 2026-05-06, the host had restarted and the root supervisor no longer contained `civilsolve-watchdog-daemon`; the script also lacked executable permission. It was fixed with `chmod 755 scripts/watchdog-daemon.py` and launched for the current boot with `nohup /usr/bin/setsid /usr/bin/python3 scripts/watchdog-daemon.py ... &`. A kill test of `supervisord-user` recovered the public health endpoint from `521` to `200` in about 15 seconds. Later on 2026-05-06 12:48 UTC, after another 521 report, the host had just rebooted at 12:46:18 UTC. CivilSolve came back under `supervisord-user`, and `scripts/watchdog-daemon.py` was added to the current `/etc/zo/supervisor.conf` as `program:civilsolve-watchdog`; `supervisorctl -c /etc/zo/supervisor.conf status civilsolve-watchdog` showed RUNNING pid 536. This is still a mitigation unless Zo makes the root-supervisor watchdog registration durable across regenerated `/etc/zo/supervisor.conf`.
- The watchdog is health-based, not a scheduled restart. Do not replace it with a normal user service, because normal user services depend on `supervisord-user` and cannot recover failure of `supervisord-user` itself.
- Do not edit `local_port`, `published_port`, `entrypoint`, `publish.entrypoint`, `publish.label`, or `publish.type` in `zosite.json`.
- If published secrets appear missing, inspect the managed service environment mapping as well as `zosite.json`.
- On 2026-05-05 the permanent 521 fix was applied to managed service `svc_nv1sMDfGXsw`: entrypoint is `bash -lc 'source /root/.zo_secrets 2>/dev/null || true; exec bun run prod'`, and service `env_vars` contains only `NODE_ENV=production`. Do not re-add secret placeholder mappings to the service metadata.

## Verification

Use these checks after code changes:

```bash
bun run build
bunx tsc --noEmit
```

For production fixes, verify the public URL with:

```bash
curl -i https://civil-engine-answer-app-vincentgpt.zocomputer.io/api/provider-health
```

If changing solve flow, also test that `/api/solve` returns `202` quickly and `/api/jobs/:jobId` eventually returns `complete`.

## Common Failure Modes

- `Unexpected token '<'`: frontend received HTML instead of JSON. Usually proxy timeout, service down, or API route falling through to SPA HTML.
- Cloudflare 521 / web server down: the published origin process is not listening. Check `service_doctor` first; if the process manager is down, restart the managed service. Avoid slow startup commands.
- If 521 returns after `supervisord-user` is killed, check root supervisor with `supervisorctl -c /etc/zo/supervisor.conf status civilsolve-watchdog` and inspect `/dev/shm/civilsolve-watchdog-daemon.log`.
- Poe charged but no result displayed: long request timed out after provider calls started. The async job flow exists to prevent this.
- `POE_API_KEY is not configured`: running service cannot see a usable Poe key. Check provider health and published service env mapping.
- `The string did not match the expected pattern`: often browser preview trouble with unsupported image types. Keep HEIC/HEIF/TIFF preview disabled.
