import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import CivilAnswerAppPage from "./pages/civil-answer-app";

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<CivilAnswerAppPage />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
