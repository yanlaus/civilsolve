import { useEffect, useMemo, useState } from "react";
import katex from "katex";
import { marked } from "marked";
import {
  Brain,
  Calculator,
  CheckCircle2,
  Download,
  FileImage,
  FileText,
  Loader2,
  PenSquare,
  Upload,
  X,
} from "lucide-react";

type ProviderKey = "codex" | "claude" | "gemini";
type ViewKey = "problem" | "assumptions" | "steps" | "answer";
type EffortKey = "none" | "low" | "medium" | "high" | "max";

type ProviderResult = {
  title: string;
  interpretedProblem: string;
  assumptions: string;
  stepByStep: string;
  finalAnswer: string;
  downloads: {
    pdf: string;
    tex: string;
  };
  error?: never;
} | {
  error: string;
  title?: never;
  interpretedProblem?: never;
  assumptions?: never;
  stepByStep?: never;
  finalAnswer?: never;
  downloads?: never;
};

type SolveResponse = {
  id: string;
  extractedPreview: Array<{
    name: string;
    mimeType: string;
    excerpt: string;
  }>;
  providers: Partial<Record<ProviderKey, ProviderResult>>;
};

type SolveStartResponse = {
  id: string;
  status: "queued" | "running";
  message?: string;
};

type JobStatusResponse =
  | {
      id: string;
      status: "queued" | "running";
      message?: string;
    }
  | {
      id: string;
      status: "complete";
      result: SolveResponse;
    }
  | {
      id: string;
      status: "error";
      error: string;
    };

type QueuedFile = {
  id: string;
  file: File;
  previewUrl?: string;
};

const views: Array<{ key: ViewKey; label: string }> = [
  { key: "problem", label: "Problem" },
  { key: "assumptions", label: "Assumptions" },
  { key: "steps", label: "Solution" },
  { key: "answer", label: "Final Answer" },
];

const providers: Array<{ key: ProviderKey; label: string; note: string }> = [
  { key: "codex", label: "ChatGPT Codex", note: "OpenAI" },
  { key: "claude", label: "Claude Sonnet", note: "via Poe" },
  { key: "gemini", label: "Gemini Pro", note: "via Poe" },
];

const efforts: Array<{ key: EffortKey; label: string }> = [
  { key: "none", label: "None" },
  { key: "low", label: "Low" },
  { key: "medium", label: "Medium" },
  { key: "high", label: "High" },
  { key: "max", label: "Max" },
];

const MAX_FILES = 10;
const MAX_FILE_SIZE = 25 * 1024 * 1024;
const JOB_POLL_INTERVAL_MS = 2500;
const JOB_POLL_TIMEOUT_MS = 30 * 60 * 1000;
const MAX_CONSECUTIVE_POLL_FAILURES = 24;
const PENDING_JOB_STORAGE_KEY = "civilsolve.pendingJobId";
const ACCEPTED_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/bmp",
  "image/heic",
  "image/heif",
  "image/avif",
  "image/tiff",
  "application/pdf",
]);

const ACCEPTED_EXTENSIONS = new Set([
  ".jpg",
  ".jpeg",
  ".png",
  ".webp",
  ".gif",
  ".bmp",
  ".heic",
  ".heif",
  ".avif",
  ".tif",
  ".tiff",
  ".pdf",
]);

const BROWSER_PREVIEWABLE_IMAGE_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/bmp",
  "image/avif",
]);

marked.setOptions({ breaks: true, gfm: true });

function sanitizeText(value: string) {
  return value
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, " ")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\u0015/g, " x ")
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function sanitizeDownloadUrl(value?: string) {
  if (!value) return "";
  return /^\/api\/jobs\/[a-f0-9-]+\/(codex|claude|gemini)\/solution\.pdf$/i.test(
    value,
  )
    ? value
    : "";
}

function protectCodeSpans(value: string) {
  const protectedChunks: string[] = [];
  const protectedText = value.replace(/```[\s\S]*?```|`[^`\n]+`/g, (match) => {
    const token = `@@CIVILSOLVE_CODE_${protectedChunks.length}@@`;
    protectedChunks.push(match);
    return token;
  });

  return { protectedText, protectedChunks };
}

function restoreCodeSpans(value: string, protectedChunks: string[]) {
  return protectedChunks.reduce(
    (current, chunk, index) => current.replaceAll(`@@CIVILSOLVE_CODE_${index}@@`, chunk),
    value,
  );
}

function normalizeMathMarkdown(value: string) {
  return autoFormatPlainMath(
    normalizeProviderArtifacts(value)
      .replace(/\s+(Step\s+\d+\s*(?:[–-]|:))/gi, "\n\n$1")
      .replace(
        /```(?:latex|tex|math)\s*([\s\S]*?)```/gi,
        (_match, expression: string) => `\n$$\n${expression.trim()}\n$$\n`,
      ),
  );
}

function normalizeProviderArtifacts(value: string) {
  return value
    .replace(/^\s*\\\s*$/gm, "")
    .replace(/(^|\n)\s*\\\s*(?=\\)/g, "$1")
    .replace(/(^|\n)\s*代入[:：]\s*/g, "$1Substitute:\n")
    .replace(/(^|\n)\s*結果[:：]\s*/g, "$1Result:\n")
    .replace(/(^|\n)\s*已知[:：]\s*/g, "$1Given:\n")
    .replace(/(^|\n)\s*所求[:：]\s*/g, "$1Required:\n")
    .replace(/(^|\n)\s*公式[:：]\s*/g, "$1Formula:\n")
    .replace(/\\times\s*\\times\s*([^\n]*?)\s*\\times\s*\\times/g, (_match, label: string) =>
      `**${label.trim()}**`,
    )
    .replace(/\\times\s+([A-Za-z][^\\\n]{1,80}?)\s*\\times/g, (_match, label: string) =>
      `**${label.trim()}**`,
    )
    .replace(/×\s*×\s*([^\n]*?)\s*×\s*×/g, (_match, label: string) =>
      `**${label.trim()}**`,
    )
    .replace(/\\begin\{align\\times\s*\}/g, "\\begin{align*}")
    .replace(/\\end\{align\\times\s*\}/g, "\\end{align*}")
    .replace(/\\section\\times\s*\{/g, "\\section*{")
    .replace(/\\text\{\s*\\mathrm\{([^{}]+)\}\s*\}/g, "\\text{$1}")
    .replace(/\\text\{\s+([^{}]+)\s+\}/g, "\\text{$1}");
}

function autoFormatPlainMath(value: string) {
  let inDisplayMath = false;

  return value
    .split("\n")
    .map((line) => {
      const trimmed = line.trim();

      if (trimmed === "$$") {
        inDisplayMath = !inDisplayMath;
        return line;
      }

      if (trimmed === "\\[" || /^\\begin\{(?:aligned|align\*?)\}/.test(trimmed)) {
        inDisplayMath = true;
        return line;
      }

      if (trimmed === "\\]" || /^\\end\{(?:aligned|align\*?)\}/.test(trimmed)) {
        inDisplayMath = false;
        return line;
      }

      if (inDisplayMath) {
        return line;
      }

      return formatPlainMathLine(line);
    })
    .join("\n");
}

function formatPlainMathLine(line: string) {
  const trimmed = line.trim();
  if (!trimmed || isMarkdownStructureLine(trimmed) || isDelimitedMathLine(trimmed)) {
    return line;
  }

  if (hasInlineMath(trimmed)) {
    return line;
  }

  const prefixMatch = trimmed.match(/^(.{1,90}:)\s+(.+)$/);
  if (prefixMatch && isMathHeavyText(prefixMatch[2])) {
    const split = splitMathTail(prefixMatch[2]);
    return `${prefixMatch[1]}\n\n$$\n${toLatexishMath(split.math)}\n$$${split.tail ? `\n\n${split.tail}` : ""}`;
  }

  const labeledMath = splitLeadingPlainTextLabel(trimmed);
  if (labeledMath && isMathHeavyText(labeledMath.math)) {
    const split = splitMathTail(labeledMath.math);
    return `${labeledMath.label}\n\n$$\n${toLatexishMath(split.math)}\n$$${split.tail ? `\n\n${split.tail}` : ""}`;
  }

  if (!isMathHeavyText(trimmed)) return line;

  const split = splitMathTail(trimmed);
  return `$$\n${toLatexishMath(split.math)}\n$$${split.tail ? `\n\n${split.tail}` : ""}`;
}

function hasInlineMath(value: string) {
  return /(^|[^\\\w])\$[^\n$]+?\$(?!\w)/.test(value) || /\\\([^\n]+?\\\)/.test(value);
}

function isMarkdownStructureLine(value: string) {
  return /^(#{1,6}\s|[-*+]\s|\d+\.\s|>|\|)/.test(value);
}

function isDelimitedMathLine(value: string) {
  return (
    value.startsWith("$$") ||
    value.endsWith("$$") ||
    value.startsWith("\\[") ||
    value.endsWith("\\]") ||
    value.startsWith("\\begin{") ||
    value.endsWith("\\end{aligned}")
  );
}

function isMathHeavyText(value: string) {
  const text = value.replace(/\\([_*])/g, "$1");
  if (!/[=≈<>±]|\b(?:frac|sqrt|sin|cos|tan)\b|\\(?:frac|sqrt|text|mathrm|gamma|sum)|[σΣΔθπγ]/i.test(text)) return false;
  const mathSignals = [
    /[A-Za-z0-9)]\s*=\s*[-+A-Za-z0-9(]/,
    /[A-Za-z][A-Za-z]?_\{?[A-Za-z0-9]+\}?/,
    /\\[A-Za-z]+/,
    /[A-Za-z][A-Za-z]?\^\d/,
    /[²³⁴⁵⁶⁷⁸⁹]/,
    /\d\s*(?:[-+*/×])\s*\d/,
    /\d\s*(?:kN|N|mm|m|MPa|Pa)\b/i,
    /[σΣΔθπ]/,
    /\b[PMVIABD]\s*=/,
  ];
  return mathSignals.some((pattern) => pattern.test(text));
}

function splitMathTail(value: string) {
  const stepMatch = value.match(/^(.*?)(\s+Step\s+\d+\s*(?:[–-]|:).*)$/i);
  if (stepMatch) {
    return { math: stepMatch[1].trim(), tail: stepMatch[2].trim() };
  }
  const tailMatch = value.match(/^(.*?)(?:,?\s+where\b|\s+Note:)\s+(.+)$/i);
  if (!tailMatch) return { math: value, tail: "" };
  return { math: tailMatch[1].trim(), tail: tailMatch[2].trim() };
}

function splitLeadingPlainTextLabel(value: string) {
  const match = value.match(
    /^([A-Z][A-Za-z\s,()/.-]{2,70}?)\s+((?:[A-Za-z]{1,3}|[σΣΔθπ]|[A-Za-z]{1,3}_[A-Za-z0-9]+)\s*(?:\\_)?[A-Za-z0-9]*\s*=.+)$/u,
  );
  if (!match) return null;
  return {
    label: match[1].replace(/\s*,\s*$/, "").trim(),
    math: match[2].trim(),
  };
}

function toLatexishMath(value: string) {
  return normalizeMathExpression(value)
    .replace(/\\([_*])/g, "$1")
    .replace(/[−–—]/g, "-")
    .replace(/[×*]/g, "\\times ")
    .replace(/·/g, "\\cdot ")
    .replace(/≈/g, "\\approx ")
    .replace(/≤/g, "\\le ")
    .replace(/≥/g, "\\ge ")
    .replace(/σ/g, "\\sigma ")
    .replace(/Σ/g, "\\Sigma ")
    .replace(/Δ/g, "\\Delta ")
    .replace(/θ/g, "\\theta ")
    .replace(/γ/g, "\\gamma ")
    .replace(/π/g, "\\pi ")
    .replace(/²/g, "^{2}")
    .replace(/³/g, "^{3}")
    .replace(/⁴/g, "^{4}")
    .replace(/⁵/g, "^{5}")
    .replace(/⁶/g, "^{6}")
    .replace(/⁷/g, "^{7}")
    .replace(/⁸/g, "^{8}")
    .replace(/⁹/g, "^{9}")
    .replace(/\\sigma\s*_([A-Za-z0-9]+)/g, "\\sigma_{$1}")
    .replace(/\\Sigma\s*_([A-Za-z0-9]+)/g, "\\Sigma_{$1}")
    .replace(/\\Delta\s*_([A-Za-z0-9]+)/g, "\\Delta_{$1}")
    .replace(/\\theta\s*_([A-Za-z0-9]+)/g, "\\theta_{$1}")
    .replace(/\\gamma\s*_([A-Za-z0-9]+)/g, "\\gamma_{$1}")
    .replace(/\\pi\s*_([A-Za-z0-9]+)/g, "\\pi_{$1}")
    .replace(/\b([A-Za-z]{1,3})_([A-Za-z0-9]+)\b/g, "$1_{$2}")
    .replace(/\b([A-Za-z]{1,3})_\{([A-Za-z0-9]+)\}/g, "$1_{$2}")
    .replace(/\b([A-Za-z]{1,3})\^([0-9]+)\b/g, "$1^{$2}")
    .replace(/\b(\d[\d,]*(?:\.\d+)?)\s*(kN|N|mm|m|MPa|Pa)\b/g, "$1\\,\\mathrm{$2}")
    .replace(/\b(mm|MPa|Pa|kN|N)\^\{(\d+)\}/g, "\\mathrm{$1}^{$2}")
    .replace(/\b(mm|MPa|Pa|kN|N)\b/g, "\\mathrm{$1}")
    .replace(/\((Compressive|Tensile|max|min)\)/gi, (_match, label: string) => `(\\text{${label}})`)
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeMathExpression(value: string) {
  return value
    .replace(/\\{2,},/g, "\\,")
    .replace(
      /\\{2,}(?=(?:left|right|frac|sqrt|gamma|text|mathrm|sum|pi|theta|sigma|Delta|Sigma)\b)/g,
      "\\",
    )
    .replace(/\\,\s*/g, " ")
    .replace(/\\([_&%#])/g, "$1")
    .replace(
      /(^|[^\\A-Za-z])(left|right|frac|sqrt|gamma|text|mathrm|sum|pi|theta|sigma|Delta|Sigma)\b/g,
      "$1\\$2",
    )
    .replace(/\\text\{\s*\\mathrm\{([^{}]+)\}\s*\}/g, "\\text{$1}")
    .replace(/\\text\{\s+([^{}]+)\s+\}/g, "\\text{$1}")
    .replace(/\\mathrm\{\s*([^{}]+)\s*\}/g, "\\mathrm{$1}")
    .replace(/,\s*\\text\{/g, "\\,\\text{")
    .replace(/\\times\s+\\times/g, "\\times")
    .trim();
}

function renderMathExpression(expression: string, displayMode: boolean) {
  return katex.renderToString(normalizeMathExpression(expression), {
    displayMode,
    throwOnError: false,
    strict: "ignore",
    trust: false,
  });
}

function replaceMathWithPlaceholders(value: string) {
  const mathHtml: string[] = [];
  let next = value;

  const addMath = (expression: string, displayMode: boolean) => {
    const token = `@@CIVILSOLVE_MATH_${mathHtml.length}@@`;
    mathHtml.push(renderMathExpression(expression, displayMode));
    return token;
  };

  next = next.replace(/\$\$([\s\S]+?)\$\$/g, (_match, expression: string) =>
    addMath(expression, true),
  );
  next = next.replace(/\\\[([\s\S]+?)\\\]/g, (_match, expression: string) =>
    addMath(expression, true),
  );
  next = next.replace(/\\\(([\s\S]+?)\\\)/g, (_match, expression: string) =>
    addMath(expression, false),
  );
  next = next.replace(/(^|[^\\\w])\$([^\n$]+?)\$(?!\w)/g, (_match, prefix: string, expression: string) =>
    `${prefix}${addMath(expression, false)}`,
  );

  return { markdown: next, mathHtml };
}

function restoreMathHtml(value: string, mathHtml: string[]) {
  return mathHtml.reduce(
    (current, html, index) => current.replaceAll(`@@CIVILSOLVE_MATH_${index}@@`, html),
    value,
  );
}

function renderMarkdown(value: string) {
  try {
    const { protectedText, protectedChunks } = protectCodeSpans(
      normalizeMathMarkdown(sanitizeText(value)),
    );
    const { markdown, mathHtml } = replaceMathWithPlaceholders(protectedText);
    const html = marked.parse(restoreCodeSpans(markdown, protectedChunks)) as string;
    return restoreMathHtml(html, mathHtml);
  } catch {
    const escaped = sanitizeText(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    return `<pre>${escaped}</pre>`;
  }
}

function canPreviewInBrowser(file: File) {
  return BROWSER_PREVIEWABLE_IMAGE_TYPES.has(file.type);
}

function getFileExtension(name: string) {
  const match = name.toLowerCase().match(/\.[a-z0-9]+$/);
  return match?.[0] || "";
}

function isAcceptedUpload(file: File) {
  return ACCEPTED_TYPES.has(file.type) || ACCEPTED_EXTENSIONS.has(getFileExtension(file.name));
}

function isErrorResult(result?: ProviderResult): result is Extract<ProviderResult, { error: string }> {
  return Boolean(result && "error" in result);
}

function sleep(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function fatalPollError(message: string) {
  return Object.assign(new Error(message), { fatalPollError: true });
}

function isFatalPollError(error: unknown) {
  return (
    error instanceof Error &&
    "fatalPollError" in error &&
    error.fatalPollError === true
  );
}

async function readJsonResponse<T>(response: Response): Promise<T> {
  const contentType = response.headers.get("content-type") || "";
  const text = await response.text();

  if (!contentType.includes("application/json")) {
    const summary = text.trim().startsWith("<!DOCTYPE") || text.trim().startsWith("<html")
      ? "The server returned an HTML page instead of JSON. This usually means the public request timed out or hit a routing error."
      : text.slice(0, 240);
    throw new Error(summary || "The server returned a non-JSON response.");
  }

  try {
    return JSON.parse(text) as T;
  } catch {
    throw new Error("The server returned invalid JSON.");
  }
}

export default function CivilAnswerAppPage() {
  const [queuedFiles, setQueuedFiles] = useState<QueuedFile[]>([]);
  const [notes, setNotes] = useState("");
  const [effort, setEffort] = useState<EffortKey>("low");
  const [selectedProviders, setSelectedProviders] = useState<ProviderKey[]>([
    "codex",
    "claude",
    "gemini",
  ]);
  const [result, setResult] = useState<SolveResponse | null>(null);
  const [activeView, setActiveView] = useState<ViewKey>("steps");
  const [activeProvider, setActiveProvider] = useState<ProviderKey>("codex");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [solveStatus, setSolveStatus] = useState("");
  const [runtimeError, setRuntimeError] = useState("");
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const pendingJobId = window.localStorage.getItem(PENDING_JOB_STORAGE_KEY);
    if (!pendingJobId) return;

    let cancelled = false;
    setIsSubmitting(true);
    setError("");
    setSolveStatus("Checking the last submitted solution...");

    waitForJob(pendingJobId)
      .then((completed) => {
        if (cancelled) return;
        showResult(completed);
        window.localStorage.removeItem(PENDING_JOB_STORAGE_KEY);
      })
      .catch((resumeError) => {
        if (cancelled) return;
        setError(
          resumeError instanceof Error
            ? resumeError.message
            : "Could not recover the previous solution.",
        );
      })
      .finally(() => {
        if (cancelled) return;
        setSolveStatus("");
        setIsSubmitting(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    return () => {
      queuedFiles.forEach((item) => {
        if (item.previewUrl) URL.revokeObjectURL(item.previewUrl);
      });
    };
  }, [queuedFiles]);

  useEffect(() => {
    const onError = (event: ErrorEvent) => {
      const detail = event.error instanceof Error ? event.error.message : event.message;
      setRuntimeError(detail || "Unexpected browser error.");
    };

    const onUnhandledRejection = (event: PromiseRejectionEvent) => {
      const detail =
        event.reason instanceof Error
          ? event.reason.message
          : typeof event.reason === "string"
            ? event.reason
            : "Unexpected browser error.";
      setRuntimeError(detail);
    };

    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);

    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
    };
  }, []);

  const resultProviders = providers.filter((provider) => result?.providers[provider.key]);
  const activeResult = result?.providers[activeProvider];

  const renderedHtml = useMemo(() => {
    if (!activeResult || isErrorResult(activeResult)) return "";
    const source =
      activeView === "problem"
        ? activeResult.interpretedProblem
        : activeView === "assumptions"
          ? activeResult.assumptions
          : activeView === "steps"
            ? activeResult.stepByStep
            : activeResult.finalAnswer;
    return renderMarkdown(source);
  }, [activeProvider, activeResult, activeView]);

  const files = queuedFiles.map((item) => item.file);
  const canSubmit = files.length > 0 && selectedProviders.length > 0 && !isSubmitting;
  const activePdfUrl =
    activeResult && !isErrorResult(activeResult)
      ? sanitizeDownloadUrl(activeResult.downloads.pdf)
      : "";

  function formatSize(bytes: number) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  }

  function addFiles(inputFiles: FileList | File[]) {
    const next = Array.from(inputFiles);
    const nextQueued: QueuedFile[] = [];
    let nextError = "";

    setQueuedFiles((current) => {
      const existingKeys = new Set(
        current.map((item) => `${item.file.name}-${item.file.size}-${item.file.lastModified}`),
      );

      for (const file of next) {
        const key = `${file.name}-${file.size}-${file.lastModified}`;
        if (existingKeys.has(key)) continue;
        if (current.length + nextQueued.length >= MAX_FILES) {
          nextError = `You can upload up to ${MAX_FILES} files at a time.`;
          break;
        }
        if (!isAcceptedUpload(file)) {
          nextError = `Unsupported file type: ${file.name}. Use images or PDFs.`;
          continue;
        }
        if (file.size > MAX_FILE_SIZE) {
          nextError = `${file.name} is larger than 25 MB.`;
          continue;
        }

        let previewUrl: string | undefined;
        if (canPreviewInBrowser(file)) {
          try {
            previewUrl = URL.createObjectURL(file);
          } catch (previewError) {
            console.error("[civilsolve-preview-url-error]", {
              fileName: file.name,
              mimeType: file.type,
              previewError,
            });
            nextError = `${file.name} could not be previewed in the browser, but you can still submit it.`;
          }
        }

        nextQueued.push({
          id: key,
          file,
          previewUrl,
        });
        existingKeys.add(key);
      }

      return [...current, ...nextQueued];
    });

    setError(nextError);
  }

  function removeFile(id: string) {
    setQueuedFiles((current) => {
      const match = current.find((item) => item.id === id);
      if (match?.previewUrl) URL.revokeObjectURL(match.previewUrl);
      return current.filter((item) => item.id !== id);
    });
  }

  function showResult(payload: SolveResponse) {
    setResult(payload);
    setActiveView("steps");
    const firstUsable =
      providers.find((provider) => {
        const providerResult = payload.providers[provider.key];
        return providerResult && !isErrorResult(providerResult);
      })?.key ??
      providers.find((provider) => payload.providers[provider.key])?.key ??
      "codex";
    setActiveProvider(firstUsable);
  }

  function toggleProvider(provider: ProviderKey) {
    setSelectedProviders((current) => {
      if (current.includes(provider)) {
        return current.filter((item) => item !== provider);
      }
      return providers
        .map((option) => option.key)
        .filter((key) => current.includes(key) || key === provider);
    });
  }

  async function waitForJob(jobId: string) {
    const startedAt = Date.now();
    let consecutivePollFailures = 0;

    while (Date.now() - startedAt < JOB_POLL_TIMEOUT_MS) {
      await sleep(JOB_POLL_INTERVAL_MS);

      try {
        const response = await fetch(`/api/jobs/${jobId}`, {
          headers: { Accept: "application/json" },
        });
        const payload = await readJsonResponse<JobStatusResponse & { error?: string }>(response);

        if (!response.ok) {
          if ([502, 503, 504].includes(response.status)) {
            throw new Error(payload.error || "The solution service is temporarily unavailable.");
          }
          throw fatalPollError(payload.error || "Could not check solution status.");
        }

        consecutivePollFailures = 0;

        if (payload.status === "complete") {
          return payload.result;
        }

        if (payload.status === "error") {
          throw fatalPollError(payload.error || "The solve job failed.");
        }

        setSolveStatus(payload.message || "Still generating solutions...");
      } catch (pollError) {
        if (isFatalPollError(pollError)) {
          throw pollError;
        }

        consecutivePollFailures += 1;
        const message =
          pollError instanceof Error
            ? pollError.message
            : "Could not check solution status.";

        if (consecutivePollFailures >= MAX_CONSECUTIVE_POLL_FAILURES) {
          throw new Error(message);
        }

        setSolveStatus(
          `Still waiting for the solution. The service check is retrying after a temporary issue: ${message}`,
        );
      }
    }

    throw new Error("The solve job is still running. Refresh the page to keep checking for the completed result.");
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canSubmit) return;

    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    selectedProviders.forEach((provider) => formData.append("providers", provider));
    formData.append("notes", notes);
    formData.append("effort", effort);

    setIsSubmitting(true);
    setError("");
    setSolveStatus("Uploading assignment...");
    setResult(null);

    try {
      const response = await fetch("/api/solve", {
        method: "POST",
        headers: { Accept: "application/json" },
        body: formData,
      });

      const payload = await readJsonResponse<
        (SolveResponse & { error?: string }) | (SolveStartResponse & { error?: string })
      >(response);
      if (!response.ok) {
        throw new Error(payload.error || "The solve request failed.");
      }

      if ("providers" in payload) {
        showResult(payload);
      } else {
        window.localStorage.setItem(PENDING_JOB_STORAGE_KEY, payload.id);
        setSolveStatus(payload.message || "Generating solutions...");
        const completed = await waitForJob(payload.id);
        showResult(completed);
        window.localStorage.removeItem(PENDING_JOB_STORAGE_KEY);
      }
    } catch (submitError) {
      setError(
        submitError instanceof Error
          ? submitError.message
          : "The solve request failed.",
      );
    } finally {
      setSolveStatus("");
      setIsSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#f4f1ec] bg-[linear-gradient(rgba(139,126,112,0.07)_1px,transparent_1px),linear-gradient(90deg,rgba(139,126,112,0.07)_1px,transparent_1px)] bg-[size:28px_28px] text-[#1b1610] dark:bg-[#0e1420] dark:bg-[linear-gradient(rgba(100,140,200,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(100,140,200,0.04)_1px,transparent_1px)] dark:text-[#e4e0db]">
      <div className="mx-auto w-full max-w-[860px] px-5 pb-16 pt-6 sm:px-6">
        <header className="py-9 text-center">
          <div className="mb-2 inline-flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-[10px] bg-[#b35c1e] text-white shadow-[0_2px_12px_rgba(179,92,30,0.15)] dark:bg-[#e8903a] dark:text-[#0e1420]">
              <Calculator className="h-5 w-5" />
            </div>
            <div className="font-serif text-[2.1rem] font-bold tracking-normal text-[#1b1610] dark:text-[#e4e0db]">
              Civil<span className="text-[#b35c1e] dark:text-[#e8903a]">Solve</span>
            </div>
          </div>
          <p className="text-xs font-medium uppercase tracking-[0.32em] text-[#8a7f72] dark:text-[#a8a098]">
            Step-by-Step Engineering Solutions
          </p>
        </header>

        <form className="space-y-5" onSubmit={handleSubmit}>
          <section>
            <p className="mb-3 flex items-center gap-2 font-serif text-lg font-semibold text-[#1b1610] dark:text-[#e4e0db]">
              <Upload className="h-4 w-4 text-[#b35c1e] dark:text-[#e8903a]" />
              Upload Assignment Materials
            </p>

            <label
              className={`relative block cursor-pointer overflow-hidden rounded-2xl border-2 border-dashed bg-white px-6 py-12 text-center shadow-[0_1px_3px_rgba(27,22,16,0.06)] transition dark:bg-[#151d2e] ${
                isDragging
                  ? "border-[#b35c1e] shadow-[0_0_0_4px_rgba(179,92,30,0.15)] dark:border-[#e8903a]"
                  : "border-[#d4cdc3] hover:border-[#b35c1e] hover:shadow-[0_0_0_4px_rgba(179,92,30,0.15)] dark:border-[#2a3650] dark:hover:border-[#e8903a]"
              }`}
              onDragOver={(event) => {
                event.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={(event) => {
                event.preventDefault();
                setIsDragging(false);
              }}
              onDrop={(event) => {
                event.preventDefault();
                setIsDragging(false);
                if (event.dataTransfer.files.length > 0) {
                  addFiles(event.dataTransfer.files);
                }
              }}
            >
              <div className="relative">
                <div className="mb-3 text-[#b35c1e] dark:text-[#e8903a]">
                  <FileImage className="mx-auto h-10 w-10" />
                </div>
                <p className="text-lg font-semibold text-[#1b1610] dark:text-[#e4e0db]">
                  Drag and drop your files here
                </p>
                <p className="mt-1 text-sm text-[#8a7f72] dark:text-[#a8a098]">
                  or <span className="font-semibold text-[#b35c1e] dark:text-[#e8903a]">browse</span> — Images and PDFs accepted
                </p>
              </div>
              <input
                type="file"
                accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp,.heic,.heif,.avif,.tif,.tiff,.pdf,application/pdf"
                multiple
                className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                aria-label="Choose assignment images or PDFs"
                onChange={(event) => {
                  if (event.target.files?.length) addFiles(event.target.files);
                  event.target.value = "";
                }}
              />
            </label>

            {queuedFiles.length > 0 ? (
              <div className="mt-4 grid grid-cols-[repeat(auto-fill,minmax(160px,1fr))] gap-3">
                {queuedFiles.map((item) => (
                  <div
                    key={item.id}
                    className="relative overflow-hidden rounded-[10px] border border-[#e8e3db] bg-white shadow-[0_1px_3px_rgba(27,22,16,0.06)] transition hover:-translate-y-0.5 hover:shadow-[0_4px_16px_rgba(27,22,16,0.08)] dark:border-[#1e2a40] dark:bg-[#151d2e]"
                  >
                    <button
                      type="button"
                      onClick={() => removeFile(item.id)}
                      className="absolute right-2 top-2 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white"
                      aria-label={`Remove ${item.file.name}`}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                    {item.previewUrl ? (
                      <img
                        src={item.previewUrl}
                        alt={item.file.name}
                        className="h-[120px] w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-[120px] w-full flex-col items-center justify-center bg-[#e8e3db] text-[#c0392b] dark:bg-[#080d15] dark:text-[#e74c3c]">
                        <FileText className="mb-1 h-9 w-9" />
                        <span className="text-[0.7rem] font-semibold uppercase tracking-[0.2em]">
                          {item.file.type === "application/pdf" ? "PDF" : "IMAGE"}
                        </span>
                      </div>
                    )}
                    <div className="flex items-center justify-between gap-2 px-3 py-2">
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-medium text-[#5c5347] dark:text-[#a8a098]">
                          {item.file.name}
                        </div>
                      </div>
                      <div className="shrink-0 text-[0.7rem] text-[#8a7f72] dark:text-[#6e6960]">
                        {formatSize(item.file.size)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}
          </section>

          <section>
            <p className="mb-3 flex items-center gap-2 font-serif text-lg font-semibold text-[#1b1610] dark:text-[#e4e0db]">
              <PenSquare className="h-4 w-4 text-[#b35c1e] dark:text-[#e8903a]" />
              Additional Instructions
              <span className="font-sans text-sm font-normal text-[#8a7f72] dark:text-[#a8a098]">(optional)</span>
            </p>
            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              rows={4}
              placeholder='e.g. "Focus on shear force diagrams" or "Show all unit conversions"'
              className="min-h-24 w-full resize-y rounded-[10px] border border-[#d4cdc3] bg-white px-4 py-3 text-base text-[#1b1610] shadow-none outline-none transition focus:border-[#b35c1e] focus:ring-4 focus:ring-[rgba(179,92,30,0.15)] dark:border-[#2a3650] dark:bg-[#151d2e] dark:text-[#e4e0db] dark:focus:border-[#e8903a]"
            />
          </section>

          <section>
            <p className="mb-3 flex items-center gap-2 font-serif text-lg font-semibold text-[#1b1610] dark:text-[#e4e0db]">
              <Calculator className="h-4 w-4 text-[#b35c1e] dark:text-[#e8903a]" />
              AI Providers
            </p>
            <div className="grid gap-3 sm:grid-cols-3">
              {providers.map((provider) => {
                const checked = selectedProviders.includes(provider.key);
                return (
                  <label
                    key={provider.key}
                    className={`flex min-h-[84px] cursor-pointer items-start gap-3 rounded-[10px] border-2 bg-white p-4 transition dark:bg-[#151d2e] ${
                      checked
                        ? "border-[#b35c1e] shadow-[0_0_0_4px_rgba(179,92,30,0.12)] dark:border-[#e8903a]"
                        : "border-[#d4cdc3] hover:border-[#b35c1e] dark:border-[#2a3650] dark:hover:border-[#e8903a]"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleProvider(provider.key)}
                      className="mt-1 h-4 w-4 accent-[#b35c1e] dark:accent-[#e8903a]"
                    />
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold text-[#1b1610] dark:text-[#e4e0db]">
                        {provider.label}
                      </span>
                      <span className="mt-1 block text-xs text-[#8a7f72] dark:text-[#a8a098]">
                        {provider.note}
                      </span>
                    </span>
                  </label>
                );
              })}
            </div>
          </section>

          <section>
            <p className="mb-3 flex items-center gap-2 font-serif text-lg font-semibold text-[#1b1610] dark:text-[#e4e0db]">
              <Brain className="h-4 w-4 text-[#b35c1e] dark:text-[#e8903a]" />
              Thinking Effort
              <span className="font-sans text-sm font-normal text-[#8a7f72] dark:text-[#a8a098]">(guides solution depth)</span>
            </p>
            <div className="flex flex-wrap gap-2">
              {efforts.map((option) => (
                <button
                  key={option.key}
                  type="button"
                  onClick={() => setEffort(option.key)}
                  className={`rounded-full border-2 px-4 py-2 text-sm font-semibold transition ${
                    effort === option.key
                      ? "border-[#b35c1e] bg-[#b35c1e] text-white shadow-[0_2px_10px_rgba(179,92,30,0.15)] dark:border-[#e8903a] dark:bg-[#e8903a] dark:text-[#0e1420]"
                      : "border-[#d4cdc3] bg-white text-[#5c5347] hover:border-[#b35c1e] hover:text-[#b35c1e] dark:border-[#2a3650] dark:bg-[#151d2e] dark:text-[#a8a098] dark:hover:border-[#e8903a] dark:hover:text-[#e8903a]"
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </section>

          {error ? (
            <div className="rounded-[10px] border border-[#f0c1bc] bg-[rgba(192,57,43,0.08)] px-4 py-3 text-sm text-[#c0392b] dark:border-[#5b2a31] dark:text-[#f2b8b2]">
              {error}
            </div>
          ) : null}

          {solveStatus ? (
            <div className="rounded-[10px] border border-[#d4cdc3] bg-white px-4 py-3 text-sm text-[#5c5347] dark:border-[#2a3650] dark:bg-[#151d2e] dark:text-[#cfc7bf]">
              {solveStatus}
            </div>
          ) : null}

          {runtimeError ? (
            <div className="rounded-[10px] border border-[#f0c1bc] bg-[rgba(192,57,43,0.08)] px-4 py-3 text-sm text-[#c0392b] dark:border-[#5b2a31] dark:text-[#f2b8b2]">
              Browser runtime error: {runtimeError}
            </div>
          ) : null}

          <div className="flex justify-center pt-1">
            <button
              type="submit"
              disabled={!canSubmit}
              className="inline-flex min-h-12 items-center justify-center gap-2 rounded-[10px] bg-[#b35c1e] px-8 py-3 text-base font-semibold text-white shadow-[0_3px_14px_rgba(179,92,30,0.15)] transition hover:-translate-y-0.5 hover:bg-[#9a4d17] disabled:cursor-not-allowed disabled:opacity-50 dark:bg-[#e8903a] dark:text-[#0e1420] dark:hover:bg-[#f5a04f] sm:px-12"
            >
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Calculator className="h-4 w-4" />}
              {isSubmitting ? "Generating solutions..." : "Solve Problems"}
            </button>
          </div>
        </form>

        <section className={`mt-10 ${result ? "block" : "hidden"}`}>
          {result ? (
            <>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <h2 className="flex items-center gap-2 font-serif text-2xl font-bold text-[#1b1610] dark:text-[#e4e0db]">
                  <CheckCircle2 className="h-5 w-5 text-[#2d8a4e] dark:text-[#3daf66]" />
                  Solutions
                </h2>
              </div>

              <div className="overflow-hidden rounded-2xl border border-[#e8e3db] bg-white shadow-[0_4px_16px_rgba(27,22,16,0.08)] dark:border-[#1e2a40] dark:bg-[#151d2e]">
                <div className="border-b-2 border-[#e8e3db] px-2 pt-1 dark:border-[#1e2a40]">
                  <div className="flex overflow-x-auto">
                    {resultProviders.map((provider) => {
                      const providerResult = result.providers[provider.key];
                      const hasError = isErrorResult(providerResult);
                      return (
                        <button
                          key={provider.key}
                          type="button"
                          onClick={() => setActiveProvider(provider.key)}
                          className={`relative shrink-0 px-4 py-3 text-left text-sm font-semibold transition ${
                            activeProvider === provider.key
                              ? "text-[#b35c1e] dark:text-[#e8903a]"
                              : "text-[#8a7f72] hover:text-[#1b1610] dark:text-[#a8a098] dark:hover:text-[#e4e0db]"
                          }`}
                        >
                          <div>{provider.label}</div>
                          <div className="text-[11px] font-normal opacity-80">{provider.note}</div>
                          <span
                            className={`absolute bottom-0 left-0 right-0 h-[3px] rounded-t ${
                              activeProvider === provider.key ? "bg-[#b35c1e] dark:bg-[#e8903a]" : "bg-transparent"
                            }`}
                          />
                          <span
                            className={`absolute right-3 top-3 h-2.5 w-2.5 rounded-full ${
                              hasError ? "bg-[#c0392b] dark:bg-[#f2b8b2]" : "bg-[#2d8a4e] dark:bg-[#3daf66]"
                            }`}
                          />
                        </button>
                      );
                    })}
                  </div>
                </div>

                {activeResult && !isErrorResult(activeResult) ? (
                  <>
                    <div className="border-b border-[#e8e3db] px-7 py-5 dark:border-[#1e2a40]">
                      <div className="mb-1 text-xs font-semibold uppercase tracking-[0.2em] text-[#8a7f72] dark:text-[#a8a098]">
                        {providers.find((provider) => provider.key === activeProvider)?.label}
                      </div>
                      <div className="font-serif text-2xl font-semibold text-[#1b1610] dark:text-[#e4e0db]">
                        {activeResult.title}
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {activePdfUrl ? (
                          <a
                            href={activePdfUrl}
                            className="inline-flex items-center gap-2 rounded-[10px] bg-[#1b1610] px-4 py-2 text-sm font-semibold text-white dark:bg-[#e8903a] dark:text-[#0e1420]"
                          >
                            <Download className="h-4 w-4" />
                            Download PDF
                          </a>
                        ) : null}
                      </div>
                    </div>

                    <div className="border-b-2 border-[#e8e3db] px-2 pt-1 dark:border-[#1e2a40]">
                      <div className="flex overflow-x-auto">
                        {views.map((view) => (
                          <button
                            key={view.key}
                            type="button"
                            onClick={() => setActiveView(view.key)}
                            className={`relative shrink-0 px-4 py-3 text-sm font-semibold transition ${
                              activeView === view.key
                                ? "text-[#b35c1e] dark:text-[#e8903a]"
                                : "text-[#8a7f72] hover:text-[#1b1610] dark:text-[#a8a098] dark:hover:text-[#e4e0db]"
                            }`}
                          >
                            {view.label}
                            <span
                              className={`absolute bottom-0 left-0 right-0 h-[3px] rounded-t ${
                                activeView === view.key ? "bg-[#b35c1e] dark:bg-[#e8903a]" : "bg-transparent"
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>

                    <article
                      className="solution-content prose prose-stone max-w-none min-w-0 overflow-x-hidden px-4 py-6 text-[1rem] leading-8 prose-headings:font-serif prose-headings:text-[#1b1610] prose-h1:border-b prose-h1:border-[#b35c1e] prose-h1:pb-2 prose-h2:text-[#b35c1e] prose-pre:overflow-x-auto prose-pre:rounded-[10px] prose-pre:border prose-pre:border-[#e8e3db] prose-pre:bg-[#e8e3db]/70 prose-code:text-[#b35c1e] dark:prose-invert dark:prose-headings:text-[#e4e0db] dark:prose-h2:text-[#e8903a] dark:prose-pre:border-[#1e2a40] dark:prose-pre:bg-[#080d15] dark:prose-code:text-[#e8903a] sm:px-7 sm:py-8 sm:text-[1.05rem]"
                      dangerouslySetInnerHTML={{ __html: renderedHtml }}
                    />
                  </>
                ) : (
                  <div className="px-7 py-8">
                    <div className="rounded-[10px] border border-[#f0c1bc] bg-[rgba(192,57,43,0.08)] px-4 py-3 text-sm text-[#c0392b] dark:border-[#5b2a31] dark:text-[#f2b8b2]">
                      {activeResult && isErrorResult(activeResult)
                        ? activeResult.error
                        : "No result available for this provider."}
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : null}
        </section>
      </div>
    </main>
  );
}
