#!/usr/bin/env python3
"""
CivilSolve Availability Watchdog — daemon mode.
Started by Zo infrastructure supervisor (PID 63), survives /etc/zo/supervisord-user.conf regeneration.
Checks if user supervisord is alive every 30s; restarts if not.
"""
import os, sys, time, subprocess, urllib.request
from pathlib import Path

SERVICE_NAME = "civil-engine-answer-app"
USER_SUPERVISOR_CONF = "/etc/zo/supervisord-user.conf"
USER_SUPERVISOR_PORT = 29011
USER_SUPERVISOR_URL = f"http://127.0.0.1:{USER_SUPERVISOR_PORT}"
HEALTH_URL = "http://127.0.0.1:52095/api/provider-health"
LOG_FILE = Path("/dev/shm/civilsolve-watchdog-daemon.log")
LOCK_FILE = Path("/tmp/civilsolve-watchdog-daemon.lock")
PID_FILE = Path("/tmp/civilsolve-watchdog-daemon.pid")

def log(msg):
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    with LOG_FILE.open("a") as f:
        f.write(f"{ts} {msg}\n")

def already_running():
    if not LOCK_FILE.exists():
        return False
    try:
        pid = int(LOCK_FILE.read_text().strip())
        os.kill(pid, 0)
        return pid != os.getpid()
    except (ValueError, ProcessLookupError, PermissionError):
        return False

def user_supervisor_alive():
    import socket
    try:
        sock = socket.create_connection(("127.0.0.1", USER_SUPERVISOR_PORT), timeout=3)
        sock.close()
        return True
    except Exception:
        return False

def start_user_supervisor():
    log("user supervisord is dead; attempting to start it")
    # Load zo secrets and start supervisord-user in the background
    cmd = (
        "source /root/.zo_secrets 2>/dev/null; "
        "nohup env -i "
        "HOME=$HOME USER=$USER PATH=$PATH "
        "ZO_CLIENT_IDENTITY_TOKEN=$ZO_CLIENT_IDENTITY_TOKEN "
        "OPENAI_API_KEY=$OPENAI_API_KEY "
        "POE_API_KEY=$POE_API_KEY "
        "/usr/local/bin/python /usr/local/bin/supervisord "
        "-c /etc/zo/supervisord-user.conf "
        "> /dev/shm/supervisord_user_startup.log 2>&1 &"
    )
    os.system(cmd)
    log(f"start command issued: {cmd[:80]}...")

def civilsolve_healthy():
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=8) as response:
            return 200 <= response.status < 300
    except Exception:
        return False

def restart_civilsolve():
    log("civilsolve health check failed; restarting service")
    subprocess.run(
        ["supervisorctl", "-c", USER_SUPERVISOR_CONF, "restart", SERVICE_NAME],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )

def main():
    if already_running():
        log("already running, exiting")
        sys.exit(0)

    pid = os.getpid()
    LOCK_FILE.write_text(str(pid))
    PID_FILE.write_text(str(pid))
    log(f"watchdog daemon started with PID {pid}")

    CHECK_INTERVAL = 30
    SUPERVISOR_UP_WAIT = 15  # wait for supervisord to be ready after start
    CIVILSOLVE_UP_WAIT = 10 # wait for civisolve to be ready after supervisor starts

    state = "idle"

    while True:
        if user_supervisor_alive():
            if not civilsolve_healthy():
                restart_civilsolve()
            else:
                log("user supervisord and civilsolve are alive")
            state = "idle"
        else:
            if state == "idle":
                log("user supervisord is NOT alive, restarting")
                start_user_supervisor()
                state = "waiting_for_supervisor"
                wait_until = time.time() + SUPERVISOR_UP_WAIT
            elif state == "waiting_for_supervisor":
                if time.time() >= wait_until:
                    if user_supervisor_alive():
                        log("user supervisord is back up, civisolve should follow")
                        state = "waiting_for_civilsolve"
                        wait_until = time.time() + CIVILSOLVE_UP_WAIT
                    else:
                        log("supervisord still not up, retrying start")
                        start_user_supervisor()
                        wait_until = time.time() + SUPERVISOR_UP_WAIT
                # else: keep waiting
            elif state == "waiting_for_civilsolve":
                if time.time() >= wait_until:
                    log(" civilsolve health check window passed")
                    state = "idle"  # will check properly next loop

        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
