#!/usr/bin/env bash
set -u

USER_SUPERVISOR_CONF="/etc/zo/supervisord-user.conf"
USER_SUPERVISOR_URL="http://127.0.0.1:29011"
SERVICE_NAME="civil-engine-answer-app"
HEALTH_URL="http://127.0.0.1:52095/api/provider-health"
LOG_FILE="/dev/shm/civilsolve-availability-watchdog.log"
ZO_SECRETS_FILE="/root/.zo_secrets"
LOCK_DIR="/tmp/civilsolve-availability-watchdog.lock"

log() {
  printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" >> "$LOG_FILE"
}

user_supervisor_status() {
  pgrep -f "supervisord -c $USER_SUPERVISOR_CONF" >/dev/null 2>&1 &&
    supervisorctl -c "$USER_SUPERVISOR_CONF" status "$SERVICE_NAME" >/dev/null 2>&1
}

start_user_supervisor() {
  log "user supervisor unavailable; starting supervisord-user"
  if [ -f "$USER_SUPERVISOR_CONF" ]; then
    python3 - "$USER_SUPERVISOR_CONF" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()
if "nodaemon=true" in text:
    path.write_text(text.replace("nodaemon=true", "nodaemon=false"))
PY
  fi
  nohup /usr/bin/setsid bash -lc "source '$ZO_SECRETS_FILE' 2>/dev/null || true; exec /usr/local/bin/supervisord -c '$USER_SUPERVISOR_CONF'" >> "$LOG_FILE" 2>&1 < /dev/null &
  log "supervisord-user start command launched as pid $!"
}

restart_service() {
  log "service health check failed; restarting $SERVICE_NAME"
  supervisorctl -c "$USER_SUPERVISOR_CONF" restart "$SERVICE_NAME" >/dev/null 2>&1 || true
}

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  log "watchdog already running; exiting duplicate"
  exit 0
fi
trap 'rmdir "$LOCK_DIR"' EXIT

log "watchdog started as pid $$"

while true; do
  if ! user_supervisor_status; then
    start_user_supervisor
    sleep 15
  fi

  if user_supervisor_status; then
    if ! curl -fsS --max-time 8 "$HEALTH_URL" >/dev/null 2>&1; then
      restart_service
      sleep 15
    fi
  fi

  sleep 10
done
