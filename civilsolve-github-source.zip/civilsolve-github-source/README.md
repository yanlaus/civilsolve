# CivilSolve

CivilSolve is a Zo Site for civil engineering assignment solving. Users upload one or more question images or PDFs, optionally add instructions, choose a thinking-effort level, and receive worked solutions from three providers:

- ChatGPT Codex
- Claude Sonnet
- Gemini Pro

Each provider result includes an interpreted problem statement, assumptions, step-by-step solution, final answer, in-browser math rendering, and a downloadable PDF when export succeeds.

The production app is published at:

```text
https://civil-engine-answer-app-vincentgpt.zocomputer.io
```

## Current Status

The published version has been verified end to end after the timeout fix:

- Public homepage loads normally
- Question uploads return quickly with a job id
- OCR and all three provider calls run in the background
- The frontend polls for results and renders completed answers
- PDF download links return `200` when generated
- Mathematical notation renders directly in the web UI through KaTeX

The important production fix is that `/api/solve` no longer waits for all provider calls in a single HTTP request. Long Poe/OpenAI calls previously caused public proxy timeout pages to be returned to the browser. The frontend then tried to parse those HTML pages as JSON and showed errors like:

```text
Unexpected token '<', "<!DOCTYPE "... is not valid JSON
```

The app now uses an asynchronous job flow to avoid that failure mode.

## User Workflow

1. Open the app.
2. Upload images or PDFs of assignment questions.
3. Optionally enter extra instructions, such as unit preferences or required method.
4. Choose thinking effort.
5. Submit.
6. The app shows progress while polling for the background job.
7. Results appear in provider tabs.
8. Users can read math-formatted solutions directly in the web UI and download provider-specific `.pdf` files.

The UI does not show the extracted OCR/PDF input preview after solving. The API still stores and returns `extractedPreview` for debugging, but the user-facing result area should stay focused on the provider solutions.

Supported upload types:

- JPEG
- PNG
- WebP
- GIF
- BMP
- AVIF
- HEIC / HEIF
- TIFF
- PDF

On mobile Safari, the file picker may provide HEIC photos with an empty MIME type. The frontend accepts uploads by MIME type or filename extension, and the backend infers the MIME type from the extension when needed. HEIC, HEIF, and TIFF files are accepted for solving, but the browser thumbnail preview is disabled for those formats because some preview iframes reject them before submission.

## Architecture

This is a Zo Site, not a plain static website.

- Runtime: Bun
- Server framework: Hono
- Frontend: React + Vite
- Styling: Tailwind CSS 4
- Markdown rendering: `marked`
- Math rendering: `katex`
- OCR: ImageMagick + Tesseract
- PDF text extraction: `pdftotext`
- Scanned PDF fallback: `pdftoppm` + Tesseract
- PDF export: `pdflatex`

### File Structure

```text
.
├── server.ts
├── scripts/
│   └── availability-watchdog.sh
├── backend-lib/
│   ├── providers.ts
│   └── zo-api.ts
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   ├── styles.css
│   └── pages/
│       └── civil-answer-app.tsx
├── public/
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
├── zosite.json
└── .data/
```

Key files:

- `server.ts`: Hono server, upload handling, OCR/PDF extraction, job polling API, export downloads, production/dev static serving.
- `backend-lib/providers.ts`: Provider configuration, OpenAI/Poe/Zo calls, schema parsing, retry handling, provider health.
- `backend-lib/zo-api.ts`: Zo fallback API helper for Codex.
- `src/pages/civil-answer-app.tsx`: Upload UI, polling, provider tabs, markdown rendering, browser-side safety checks.
- `.data/jobs/`: Runtime job storage. This is generated output and is intentionally ignored by Git.

## API

### `GET /api/provider-health`

Returns safe provider configuration status without exposing secret values.

Use this first when debugging provider setup.

Example shape:

```json
{
  "codex": { "configured": true, "source": "openai" },
  "claude": { "configured": true, "source": "poe" },
  "gemini": { "configured": true, "source": "poe" }
}
```

Codex may also report `source: "zo"` when it is using Zo's Codex fallback.

### `POST /api/solve`

Accepts a multipart form:

- `files`: one or more uploaded images/PDFs
- `notes`: optional user instructions
- `effort`: `none`, `low`, `medium`, `high`, or `max`

It saves the upload, creates a job, starts background processing, and returns immediately:

```json
{
  "id": "job-uuid",
  "status": "queued",
  "message": "Assignment uploaded. Solutions are being generated."
}
```

The response status is `202`.

Do not change this back to a long blocking request. The published site needs this job pattern to avoid public proxy timeouts.

### `GET /api/jobs/:jobId`

Returns job state.

While running:

```json
{
  "id": "job-uuid",
  "status": "running",
  "message": "Asking ChatGPT Codex, Claude Sonnet, and Gemini Pro."
}
```

When complete:

```json
{
  "id": "job-uuid",
  "status": "complete",
  "result": {
    "id": "job-uuid",
    "extractedPreview": [],
    "providers": {
      "codex": {},
      "claude": {},
      "gemini": {}
    }
  }
}
```

If a provider fails, only that provider gets an `{ "error": "..." }` result. The whole job should still complete when other providers succeed.

### `GET /api/jobs/:jobId/:provider/solution.pdf`

Downloads a provider PDF.

### `GET /api/jobs/:jobId/:provider/solution.tex`

Downloads a provider LaTeX source file.

This route is retained for internal/debug compatibility and PDF generation artifacts, but the frontend does not expose a TeX download button. The user-facing download option is PDF only.

## Background Job Flow

The solve flow is intentionally asynchronous:

1. `/api/solve` validates and stores uploads under `.data/jobs/<job-id>/uploads/`.
2. The server writes `status.json` with `queued`.
3. `processSolveJob(...)` starts in the background.
4. OCR/PDF extraction runs.
5. The server asks all providers in parallel.
6. Each provider response is normalized into the internal solution shape.
7. The server writes provider `.tex` and tries to compile `.pdf`.
8. If provider LaTeX fails, the server falls back to safer generated LaTeX.
9. If PDF still fails, the answer still renders in the web UI.
10. The server writes `result.json`.
11. The frontend polls `/api/jobs/:jobId` until complete.

This design prevents this production failure:

- Provider request succeeds and credits are charged
- Public proxy times out the original browser request
- Browser receives an HTML error page
- Frontend tries `response.json()`
- User sees `Unexpected token '<'`

## Provider Configuration

Provider keys must stay server-side. Do not expose them in frontend code.

Expected environment variables:

- `POE_API_KEY`: required for Claude Sonnet and Gemini Pro.
- `OPENAI_API_KEY`: preferred direct OpenAI key for ChatGPT Codex.
- `CODEX_API_KEY`: optional alternate direct OpenAI key for ChatGPT Codex.
- `ZO_CLIENT_IDENTITY_TOKEN`: Zo-provided token used for Codex fallback when no valid direct OpenAI key is available.
- `OPENAI_MODEL`: optional model override. Default is `gpt-5.2-codex`.
- `POE_CLAUDE_MODEL`: optional Poe model override. Default is `Claude-Sonnet-4.6`.
- `POE_GEMINI_MODEL`: optional Poe model override. Default is `Gemini-3.1-Pro`.
- `ZO_CODEX_MODEL`: optional Zo fallback model override.

Important behavior:

- If `OPENAI_API_KEY` or `CODEX_API_KEY` looks like a real OpenAI key, Codex uses OpenAI's Responses API directly.
- If the OpenAI key is missing, contains a Poe key, or contains a Zo token, Codex falls back to Zo's Codex channel when `ZO_CLIENT_IDENTITY_TOKEN` exists.
- `POE_API_KEY` must look like a Poe key for Claude/Gemini to be configured.

The published Zo service must have the correct secret variables mapped into its environment. If Secrets exist in Zo but `/api/provider-health` says they are missing, check the published service environment mapping.

## Published Service Notes

The Zo system manages this site. Do not manually run or stop the server process.

Use Zo's site/service management when a publish restart is needed. The site is defined by `zosite.json`, but most fields are system-managed.

The production entrypoint is intentionally a fast server start:

```json
"prod": "NODE_ENV=production bun run server.ts"
```

Do not change it back to `bun run build && ...`. The build must happen before deployment/restart, not while the public service is starting. Building during startup leaves the published port closed; if Cloudflare reaches the origin during that window, users can see:

```text
Web server is down
Error code 521
```

For long-term uptime, keep deploys as:

1. Run `bun run build`.
2. Run `bunx tsc --noEmit`.
3. Restart/update the managed published service so it serves the already-built `dist/`.
4. Verify `GET /api/provider-health` on the public URL.

### Availability Watchdog

Cloudflare `521` has occurred when Zo's user-service supervisor (`supervisord-user`) was terminated and did not automatically come back. In that state, CivilSolve is not listening on port `52095`, so Cloudflare cannot connect to the origin.

This project now includes a lightweight watchdog:

```text
scripts/watchdog-daemon.py
```

It is intended to run outside `supervisord-user` so it can recover `supervisord-user` itself. If the host was restarted or Zo regenerated `/etc/zo/supervisor.conf`, verify whether it is still registered under the root supervisor as:

```text
civilsolve-watchdog-daemon
```

The watchdog:

- checks whether `supervisord-user` is alive
- starts `supervisord-user` if needed
- checks `http://127.0.0.1:52095/api/provider-health`
- restarts only `civil-engine-answer-app` if the user supervisor is alive but the app health check fails
- logs to `/dev/shm/civilsolve-watchdog-daemon.log`

This is not a scheduled app restart. It is a health-based recovery loop. It should not interrupt a healthy running app.

Check it with:

```bash
supervisorctl -c /etc/zo/supervisor.conf status civilsolve-watchdog-daemon
tail -n 40 /dev/shm/civilsolve-watchdog-daemon.log
```

On 2026-05-06, the root supervisor entry was missing after a host restart, and the script was not executable. The current-boot recovery was:

```bash
chmod 755 scripts/watchdog-daemon.py
nohup /usr/bin/setsid /usr/bin/python3 scripts/watchdog-daemon.py >> /dev/shm/civilsolve-watchdog-daemon.launch.log 2>&1 < /dev/null &
```

That was verified by killing `supervisord-user`; the watchdog restarted it and the public health endpoint recovered from `521` to `200` in about 15 seconds.

When present, the root supervisor config contains the watchdog program entry in:

```text
/etc/zo/supervisor.conf
```

That file is outside the Git repo, so if the Zo host image is rebuilt from scratch, verify that the watchdog entry still exists.

Safe to edit:

- `name`
- `env`
- `publish.env`

Do not edit:

- `local_port`
- `published_port`
- `entrypoint`
- `publish.entrypoint`
- `publish.label`
- `publish.type`

`publish.env` currently contains only:

```json
{
  "NODE_ENV": "production"
}
```

Zo service-level environment mappings may also be applied outside this file after publishing. If the published site reports missing secrets, inspect the managed service, not only `zosite.json`.

Permanent 521 fix applied on 2026-05-05:

- The managed service metadata was corrected at the source (`svc_nv1sMDfGXsw`), not only in `/etc/zo/supervisord-user.conf`.
- The published service entrypoint is `bash -lc 'source /root/.zo_secrets 2>/dev/null || true; exec bun run prod'`.
- The managed service `env_vars` should contain only `NODE_ENV=production`.
- Do not add `OPENAI_API_KEY`, `POE_API_KEY`, or `ZO_CLIENT_IDENTITY_TOKEN` as `%(ENV_...)s` service env mappings. Those placeholders can be regenerated into `/etc/zo/supervisord-user.conf` and prevent `supervisord-user` from starting.
- If the supervisor config is regenerated, the CivilSolve program should still look like: command sources `/root/.zo_secrets`; environment contains `NODE_ENV="production",PORT="52095"` only.

## Frontend Error Handling

The frontend intentionally avoids blindly calling `response.json()`.

`readJsonResponse(...)` first reads the response as text and checks the `Content-Type`. If the server returns HTML, it shows a readable error instead of crashing with `Unexpected token '<'`.

The frontend also:

- Logs uncaught browser errors through global `error` and `unhandledrejection` listeners.
- Shows the latest browser runtime error inline.
- Sanitizes markdown before rendering.
- Renders common math delimiters through KaTeX: `$...$`, `$$...$$`, `\(...\)`, and `\[...\]`.
- Converts common plain-text engineering formulas from Claude/Gemini into KaTeX-friendly display math. Examples include `A = B * D`, `F_{1} = \gamma A_{1} h_{1}`, `I_xx = ...`, `σ_max = ...`, superscript units like `mm²`, and unit expressions such as `20 kN`.
- Cleans provider formatting artifacts before rendering in all result tabs, including `\times heading \times`, `\times \times heading \times \times`, nested unit markup such as `\text{\mathrm{mm}}`, escaped subscripts such as `e\_{x}`, and zero-width characters in malformed JSON keys.
- Repairs malformed mobile/Safari-visible LaTeX artifacts before KaTeX rendering, including stripped leading commands such as `frac{...}` / `left(...)` and over-escaped spacing such as `\\\\,`.
- Cleans common CJK calculation labels such as `代入`, `結果`, `已知`, `所求`, and `公式` into English labels when they appear in older provider output.
- Keeps solution content responsive so long text, tables, code blocks, and equations do not create whole-page horizontal scrolling.
- Sanitizes download URLs before using them in `<a href>`.
- Allows HEIC/HEIF/TIFF uploads without browser thumbnail previews.

## Provider Output Safety

Provider responses can be messy. The backend handles these cases:

- Control characters are stripped before saving results.
- Invalid download paths are removed.
- Codex/Poe JSON responses are normalized when field names differ.
- Codex fallback responses are repaired when Zo returns a short thinking preface followed by a JSON object, so only the structured answer reaches the frontend.
- Plain-text provider output can be converted into a best-effort structured result.
- LaTeX fences and full-document wrappers are stripped before export.
- Provider prompts explicitly require English by default and translation of non-English OCR text unless the user asks for another language.
- Broken provider LaTeX falls back to server-generated LaTeX for PDF export.
- PDF export failure does not block answer rendering.

## Runtime Dependencies

These command-line tools must be available on the Zo machine:

- `convert` from ImageMagick
- `tesseract`
- `pdftotext`
- `pdftoppm`
- `pdflatex`

Quick check:

```bash
which convert tesseract pdftotext pdftoppm pdflatex
```

## Development And Verification

Zo manages the dev and production server lifecycle. Do not start `bun run dev` or `bun run prod` manually for normal operation.

Useful checks:

```bash
bun run build
bunx tsc --noEmit
git status --short
```

`bun --check server.ts` may collide with the already-running Zo preview port because this server exports and starts through Zo's runtime pattern. Prefer `bun run build` and focused endpoint tests.

For local preview debugging, use the port from `zosite.json`:

```bash
agent-browser open http://localhost:$PORT
agent-browser snapshot -i
agent-browser screenshot --full-page --filename debug.png
```

Do not send localhost URLs to users. Use the published public URL or the Zo preview UI.

## Logs

Logs are stored under `/dev/shm/`.

Common files:

- `/dev/shm/zosite-<port>.log`
- `/dev/shm/zosite-<port>-browser.log`
- `/dev/shm/zosite-<port>-proxy.log`
- published service logs may use service-specific names instead of the `zosite-` prefix

Useful browser log prefixes:

- `civilsolve-preview-url-error`
- `civilsolve-runtime-error`
- `civilsolve-unhandled-rejection`

Server startup logs include provider health:

```text
[startup] provider health {...}
```

## Troubleshooting

### `Unexpected token '<', "<!DOCTYPE "... is not valid JSON`

Meaning: the frontend received HTML where JSON was expected.

Most likely causes:

- Published proxy timeout
- Public service down
- API route fell through to SPA HTML

### Cloudflare `521 Web server is down`

Meaning: Cloudflare and the Zo edge were reachable, but the CivilSolve origin process was not accepting connections on the published port.

Most likely causes:

- Zo's user process manager is down.
- The CivilSolve service process is stopped or not registered in the process manager.
- The service is starting slowly and has not opened its port yet.
- A production restart was triggered while the entrypoint was still building the frontend.

Check:

```bash
service_doctor civil-engine-answer-app
```

Expected healthy state:

- process manager running
- service process found
- port listening on `52095`
- `https://civil-engine-answer-app-vincentgpt.zocomputer.io/api/provider-health` returns JSON

Long-term prevention:

- Keep production startup fast and do not build in `bun run prod`.
- Build before restarting the service.
- Keep `/api/solve` asynchronous so provider calls cannot hold the public request open.
- Use the managed Zo service supervisor rather than manually running the server.
- Keep `civilsolve-watchdog-daemon` running under the root supervisor so `supervisord-user` and the CivilSolve origin are recovered automatically if they are terminated.
- Cloudflare returned an HTML error page

Current mitigation:

- `/api/solve` returns a job id immediately
- frontend polls `/api/jobs/:jobId`
- non-JSON responses are reported clearly

If this returns, inspect public service logs and test:

```bash
curl -i https://civil-engine-answer-app-vincentgpt.zocomputer.io/api/provider-health
```

### Poe credits deducted but no solution displayed

Meaning: provider calls likely completed after the browser request failed or timed out.

Check `.data/jobs/<job-id>/result.json` if the job id is known, or inspect recent `.data/jobs` folders. The current async job flow is intended to prevent this issue.

### `POE_API_KEY is not configured on the server`

Meaning: the running service does not see a usable Poe key.

Check:

- Secret exists in Zo Settings
- Published service entrypoint sources `/root/.zo_secrets`
- `/api/provider-health` shows Claude/Gemini configured
- Key value is a Poe key, not an OpenAI or Zo token

Do not print secret values in logs or terminal output.

### `OPENAI_API_KEY is not configured on the server`

Codex can still work through Zo fallback if `ZO_CLIENT_IDENTITY_TOKEN` is present. Use `/api/provider-health` to see whether Codex source is `openai` or `zo`.

If direct OpenAI is required, set a real OpenAI key in `OPENAI_API_KEY` or `CODEX_API_KEY`.

### `The string did not match the expected pattern`

This has previously been caused by browser-only handling of unsupported image previews, especially HEIC/HEIF/TIFF inside the Zo preview iframe.

Current mitigation:

- HEIC/HEIF/TIFF are accepted but not previewed through `<img>`
- preview URL creation is wrapped in `try/catch`
- runtime browser errors are surfaced inline

### Provider returns invalid JSON

The backend now tries to normalize common alternate JSON shapes and can synthesize a structured result from plain text. If a provider still fails, the failure should be limited to that provider tab.

### PDF export fails

PDF export is best effort. The app should still show the answer and provide TeX if possible. Check logs for:

```text
[pdf-export:<job-id>:<provider>]
```

## Git Hygiene

Generated runtime data is ignored:

```text
.data/
dist/
node_modules/
```

Keep `.data/jobs` out of commits. It may contain user-uploaded assignment materials and generated answers.

## Maintenance Rules

- Keep provider keys server-side only.
- Keep `/api/solve` asynchronous.
- Do not turn provider failures into whole-job failures unless OCR/upload itself failed.
- Do not rely on long public HTTP requests for provider generation.
- Do not manually edit Zo-managed ports or entrypoints.
- Update this README whenever architecture, provider behavior, deployment, or error handling changes.
